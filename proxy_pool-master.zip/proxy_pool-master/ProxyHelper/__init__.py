# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     __init__.py
   Description :
   Author :        JHao
   date：          2019/7/11
-------------------------------------------------
   Change Activity:
                   2019/7/11:
-------------------------------------------------
"""
__author__ = 'JHao'

from ProxyHelper.Proxy import Proxy
from ProxyHelper.ProxyUtil import checkProxyUseful
