# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     __init__.py.py  
   Description :  
   Author :       JHao
   date：          2016/11/25
-------------------------------------------------
   Change Activity:
                   2016/11/25: 
-------------------------------------------------
"""

from Util.utilFunction import validUsefulProxy
from Util.LogHandler import LogHandler
from Util.utilClass import Singleton
