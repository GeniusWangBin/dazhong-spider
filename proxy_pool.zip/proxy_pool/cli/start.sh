#!/usr/bin/env bash
python proxyPool.py webserver &
python proxyPool.py schedule