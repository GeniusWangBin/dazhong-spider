from proxypool.importer import scan

if __name__ == '__main__':
    scan()